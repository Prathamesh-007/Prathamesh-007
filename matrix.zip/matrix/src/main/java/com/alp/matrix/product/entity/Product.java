package com.alp.matrix.product.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer id;

	String name;
	String type;

	@ManyToOne
	@JoinColumn(name = "vendorId", referencedColumnName = "id")
	Integer vendorId;

	@JoinColumn(name = "vendorName", referencedColumnName = "name")
	String vendorName;

	Float price;
	Integer quantity;

	public Product() {
		super();
	}

	public Product(Integer id, String name, String type, Integer vendorId, String vendorName, Float price,
			Integer quantity) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.price = price;
		this.quantity = quantity;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
