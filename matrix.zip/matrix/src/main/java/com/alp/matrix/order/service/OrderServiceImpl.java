package com.alp.matrix.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alp.matrix.order.entity.Order;
import com.alp.matrix.order.repo.OrderRepo;
import com.itextpdf.layout.Document;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderRepo orderRepo;

	@Override
	public Order save(Order order) {
		return orderRepo.save(order);
	}

	@Override
	public List<Order> findAll() {
		return orderRepo.findAll();
	}

	@Override
	public Order update(Order order) {
		return orderRepo.save(order);
	}

	@Override
	public Order findById(Integer id) {
		return orderRepo.findById(id).orElse(null);
	}

	@Override
	public List<Order> findByCustomerId(Integer id) {
		return orderRepo.findByCustomerId(id);
		
		
	}

	@Override
	public void dispatch(Order order) {
		order.setStatus("dispatched");
		Document invoice = Invoice.generateInvoice(order);
		byte[] byteInvoice = Invoice.toByteArray(invoice);
		order.setInvoice(byteInvoice);
		
		orderRepo.save(order);

	}

}
