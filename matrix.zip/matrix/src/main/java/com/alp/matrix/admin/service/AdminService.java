package com.alp.matrix.admin.service;

import java.util.List;

import com.alp.matrix.admin.entity.Admin;

import com.alp.matrix.vendor.entity.Vendor;

import com.alp.matrix.order.entity.Order;

public interface AdminService {
	public Admin save(Admin admin);

	public List<Admin> findAll();

	public Admin findById(Integer id);

	public void acceptVendor(Vendor vendor);

	public void removeVendor(Vendor vendor);

	public boolean login(Integer id, String password);

	public List<Order> findAllOrders();

	public void dispatch(Order order);

}
