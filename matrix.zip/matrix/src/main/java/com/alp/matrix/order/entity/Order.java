package com.alp.matrix.order.entity;

import java.util.List;

import org.hibernate.annotations.Type;

import com.alp.matrix.product.entity.Product;
import com.vladmihalcea.hibernate.type.json.JsonType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;

@Entity
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer id;

	@ManyToOne
	@JoinColumn(name = "customerId", referencedColumnName = "id")
	Integer customerId;

	@Type(value = JsonType.class)
	@Column(columnDefinition = "json")
	List<Product> products;

	Float totalPrice;
	String status;

	@Lob
	byte[] invoice;

	public Order() {
		super();
	}

	public Order(Integer id, Integer customerId, List<Product> products, Float totalPrice,
			String status, byte[] invoice) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.products = products;
		this.totalPrice = totalPrice;
		this.status = status;
		this.invoice = invoice;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomer() {
		return customerId;
	}

	public void setCustomer(Integer customerId) {
		this.customerId = customerId;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Float totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public byte[] getInvoice() {
		return invoice;
	}

	public void setInvoice(byte[] invoice) {
		this.invoice = invoice;
	}

}
