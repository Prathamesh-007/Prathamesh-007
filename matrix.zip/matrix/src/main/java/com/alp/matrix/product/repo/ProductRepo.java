package com.alp.matrix.product.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alp.matrix.product.entity.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product, Integer> {
	public List<Product> findByVendorId(Integer id);
	public List<Product> findByVendorName(String name);
	public List<Product> findByName(String name);
	public List<Product> findByType(String type);

}
