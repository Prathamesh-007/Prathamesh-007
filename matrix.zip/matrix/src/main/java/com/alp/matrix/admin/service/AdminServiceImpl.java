package com.alp.matrix.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alp.matrix.admin.entity.Admin;
import com.alp.matrix.admin.repo.AdminRepo;

import com.alp.matrix.vendor.entity.Vendor;
import com.alp.matrix.vendor.service.VendorService;

import com.alp.matrix.order.entity.Order;
import com.alp.matrix.order.service.OrderService;

import com.alp.matrix.product.service.ProductService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminRepo adminRepo;

	@Autowired
	VendorService vendorService;

	@Autowired
	ProductService productService;

	@Autowired
	OrderService orderService;

	@Override
	public Admin save(Admin admin) {
		return adminRepo.save(admin);
	}

	@Override
	public List<Admin> findAll() {
		return adminRepo.findAll();
	}

	@Override
	public Admin findById(Integer id) {
		return adminRepo.findById(id).orElse(null);
	}

	@Override
	public void acceptVendor(Vendor vendor) {
		vendor.setStatus("active");
		vendorService.save(vendor);
	}

	@Override
	public void removeVendor(Vendor vendor) {
		vendor.setStatus("inactive");
		productService.removeProductsByVendorId(vendor.getId());
		vendorService.update(vendor);
		// We can write a trigger on vendor table update but that might be resource
		// intensive
	}

	@Override
	public boolean login(Integer id, String password) {
		try {
			Admin admin = adminRepo.findById(id).orElse(null);
			if (admin.getPassword().equals(password))
				return true;
			else
				return false;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}

	@Override
	public List<Order> findAllOrders() {
		return orderService.findAll();

	}

	@Override
	public void dispatch(Order order) {
		orderService.dispatch(order);

	}

}
