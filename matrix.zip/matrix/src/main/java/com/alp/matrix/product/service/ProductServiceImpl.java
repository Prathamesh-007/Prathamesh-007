package com.alp.matrix.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.alp.matrix.product.entity.Product;
import com.alp.matrix.product.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepo productRepo;

	@Override
	public Product save(Product product) {
		return productRepo.save(product);
	}

	@Override
	public List<Product> findAll() {
		return productRepo.findAll();
	}

	@Override
	public Product findById(Integer id) {
		return productRepo.findById(id).orElse(null);
	}

	@Override
	public Product update(Product product) {
		return productRepo.save(product); 
	}

	@Override
	public List<Product> findByType(String type) {
		return productRepo.findByType(type);
	}

	@Override
	public List<Product> findByVendorName(String vendorName) {
		return productRepo.findByVendorName(vendorName);
	}

	@Override
	public void addToCart(Product product, Integer cartId) {
		Cart cart = cartService.findById(cartId);
		List<Product> products = cart.getProducts();
		products.add(product);
		cart.setProducts(products);
		cartService.save(cart);

	}

	@Override
	public Product findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void removeProductsByVendorId(Integer vendorId) {
		// TODO Auto-generated method stub
		
	}

}
