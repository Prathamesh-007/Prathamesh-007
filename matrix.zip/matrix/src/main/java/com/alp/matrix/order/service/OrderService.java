package com.alp.matrix.order.service;

import java.util.List;

import com.alp.matrix.order.entity.Order;

public interface OrderService {
	public Order save(Order order);
	public List<Order> findAll();
	public Order update(Order order);
	public Order findById(Integer id);
	public List<Order> findByCustomerId(Integer id);
	public void dispatch(Order order);
}
