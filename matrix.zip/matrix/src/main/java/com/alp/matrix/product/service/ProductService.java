package com.alp.matrix.product.service;

import java.util.List;

import com.alp.matrix.product.entity.Product;

public interface ProductService {
	public Product save(Product product);
	public List<Product> findAll();
	public Product findById(Integer id);
	public Product update(Product product);
	public List<Product> findByType(String type);
	public List<Product> findByVendorName(String vendorName);
	public void addToCart(Product product, Integer id);
	public Product findByName(String name);
	public void removeProductsByVendorId(Integer vendorId);

}
