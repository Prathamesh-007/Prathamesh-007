package com.alp.matrix.order.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.alp.matrix.order.entity.Order;

@Repository
public interface OrderRepo extends JpaRepository<Order, Integer> {
	public List<Order> findByCustomerId(Integer id);

}
