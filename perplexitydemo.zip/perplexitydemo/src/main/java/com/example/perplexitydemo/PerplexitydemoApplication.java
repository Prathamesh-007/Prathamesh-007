package com.example.perplexitydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerplexitydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerplexitydemoApplication.class, args);
	}

}
