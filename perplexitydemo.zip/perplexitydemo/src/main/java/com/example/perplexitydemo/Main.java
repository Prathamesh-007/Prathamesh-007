package com.example.perplexitydemo;

//"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";

import java.net.http.*;
import java.net.URI;
import java.util.*;
import com.google.gson.Gson;

public class Main {
	// Helper classes to parse JSON response
	static class ApiResponse {
		List<Choice> choices;
	}

	static class Choice {
		Message message;
	}

	static class Message {
		String content;
	}

	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your question: ");
		String question = scanner.nextLine();

		String apiKey = "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";
		HttpClient client = HttpClient.newHttpClient();

		// Build request body with user's question
		Map<String, Object> message = new HashMap<>();
		message.put("role", "user");
		message.put("content", question);

		Map<String, Object> requestBody = new HashMap<>();
		requestBody.put("model", "llama-3.1-sonar-small-128k-online");
		requestBody.put("messages", List.of(message));

		HttpRequest request = HttpRequest.newBuilder().uri(URI.create("https://api.perplexity.ai/chat/completions"))
				.header("Authorization", "Bearer " + apiKey).header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(new Gson().toJson(requestBody))).build();

		HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

		if (response.statusCode() == 200) {
			ApiResponse apiResponse = new Gson().fromJson(response.body(), ApiResponse.class);
			if (!apiResponse.choices.isEmpty()) {
				System.out.println("\nAnswer: " + apiResponse.choices.get(0).message.content);
			} else {
				System.out.println("No response from API");
			}
		} else {
			System.out.println("Error: " + response.statusCode() + " - " + response.body());
		}
	}
}
