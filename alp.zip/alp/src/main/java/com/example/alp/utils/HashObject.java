package com.example.alp.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashObject {

    public static String toMD5(String input) throws NoSuchAlgorithmException {

        MessageDigest messageDigest = MessageDigest.getInstance("MD5");

        byte[] hashBytes = messageDigest.digest(input.getBytes());

        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            hexString.append(String.format("%02x", b));
        }
        
        return hexString.toString();
    }

    
}
