package com.example.alp.customer.entity.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.alp.customer.entity.Customer;

@Service
public interface CustomerService {
	public Customer saveCustomer(Customer customer);
	public Customer findById(String id);
	public Customer updateCustomer(Customer customer);
	public List<Customer> findAll();
	public List<Customer> findByCountry(String country);

}
