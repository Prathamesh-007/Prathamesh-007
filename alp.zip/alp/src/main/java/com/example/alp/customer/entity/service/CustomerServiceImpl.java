package com.example.alp.customer.entity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.alp.customer.entity.Customer;
import com.example.alp.customer.entity.repo.CustomerRepo;

public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepo repo;
	
	@Override
	public Customer saveCustomer(Customer customer) {
		return repo.save(customer);
	}

	@Override
	public Customer findById(String id) {
		return repo.findById(id).orElse(null);
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		return repo.save(customer);
	}

	@Override
	public List<Customer> findAll() {
		return repo.findAll();
	}

	@Override
	public List<Customer> findByCountry(String country) {
		return repo.findByCountry(country);
	}

}
