package com.example.alp.utils;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

@SuppressWarnings("serial")
public class IdGenerator implements IdentifierGenerator {

	@Override
	public Object generate(SharedSessionContractImplementor session, Object object) {
		
		String entityName = object.getClass().getSimpleName();
		String prefix = getPrefix(entityName);
		
		String query = "SELECT COUNT(e) FROM " + entityName + " e";
		
		@SuppressWarnings("deprecation")
		Long count = (Long)session.createQuery(query).uniqueResult();
		
		return prefix + (count==null || count==0 ? 1 : count+1);
	}

	private String getPrefix(String entityName) {
		if(entityName.equals("Customer"))
			return "C";
		
		if(entityName.equals("Vendor"))
			return "V";
		
		throw new IllegalArgumentException("Unknown prefix generation for entity: " + entityName);
	}
	
	

}
