package com.example.alp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlpApplication.class, args);
	}

}
