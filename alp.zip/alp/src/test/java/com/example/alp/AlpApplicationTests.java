package com.example.alp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlpApplicationTests {

	@Test
	void contextLoads() {
	}

}
