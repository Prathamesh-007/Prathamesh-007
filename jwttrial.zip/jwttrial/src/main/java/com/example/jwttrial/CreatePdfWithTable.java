package com.example.jwttrial;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;

public class CreatePdfWithTable {

    public static void main(String[] args) {
        try {
            // Specify the file path for the PDF
            String dest = "example_with_table.pdf";
            
            // Initialize PdfWriter
            PdfWriter writer = new PdfWriter(dest);
            
            // Initialize PdfDocument
            PdfDocument pdf = new PdfDocument(writer);
            
            // Initialize Document
            Document document = new Document(pdf);
            
            // Add a title
            document.add(new Paragraph("Sample PDF with Table"));
            
            // Create a table with 3 columns
            float[] columnWidths = {1, 3, 2}; // Define the widths of the columns
            Table table = new Table(columnWidths);
            
            // Add header row to the table
            table.addCell(new Cell().add(new Paragraph("ID")));
            table.addCell(new Cell().add(new Paragraph("Name")));
            table.addCell(new Cell().add(new Paragraph("Age")));
            
            // Add some data rows to the table
            table.addCell(new Cell().add(new Paragraph("1")));
            table.addCell(new Cell().add(new Paragraph("Alice")));
            table.addCell(new Cell().add(new Paragraph("30")));
            
            table.addCell(new Cell().add(new Paragraph("2")));
            table.addCell(new Cell().add(new Paragraph("Bob")));
            table.addCell(new Cell().add(new Paragraph("25")));
            
            table.addCell(new Cell().add(new Paragraph("3")));
            table.addCell(new Cell().add(new Paragraph("Charlieeeeeeeeeee")));
            table.addCell(new Cell().add(new Paragraph("35")));
            
            // Add the table to the document
            document.add(table);
            
            // Close the document
            document.close();
            
            System.out.println("PDF with table created successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
