package com.example.jwttrial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwttrialApplicationTests {

	@Test
	void contextLoads() {
	}

}
