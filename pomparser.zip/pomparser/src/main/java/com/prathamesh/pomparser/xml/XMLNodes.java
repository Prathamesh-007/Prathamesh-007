package com.prathamesh.pomparser.xml;

public enum XMLNodes {
	params,
	filePath,
	relativeFilePath,
	functionName,
	arguments,
	argument;
	
	public static boolean isValid(String input) {
		try {
			XMLNodes.valueOf(input);
			return true;
		} catch(IllegalArgumentException e) {
			System.out.println(e);
			return false;
		}
	}
	
}
