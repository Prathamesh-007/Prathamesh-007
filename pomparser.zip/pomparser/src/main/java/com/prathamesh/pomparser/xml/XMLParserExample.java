package com.prathamesh.pomparser.xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class XMLParserExample {

    public static void parser(String xmlFile) {    	
        try {
        	
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

            DocumentBuilder builder = factory.newDocumentBuilder();

            Document document = builder.parse(new File(xmlFile));

            document.getDocumentElement().normalize();

            Element root = document.getDocumentElement();
            System.out.println("Root element: " + root.getNodeName());
            
            Element filePath = (Element)document.getElementsByTagName("filePath").item(0);
            System.out.println("File Path: " + filePath.getTextContent().trim());
            
            Node arguments = document.getElementsByTagName("arguments").item(0);
            System.out.println("Arguments:");
            
            
            Element javaVersion = (Element) document.getElementsByTagName("java.version").item(0);
            
            NodeList argList = arguments.getChildNodes();
            for(int i=0;i<argList.getLength();i++) {
            	Node argument = argList.item(i);
            	if(argument.getNodeType()==Node.ELEMENT_NODE) {
            		String textContent = argument.getTextContent();
            		if(!textContent.isEmpty()) {
            			System.out.println("\t" + textContent);
            			functionArgsList.add(textContent);
            		}
            	}
            }
            
            NodeList dependencies = document.getElementsByTagName("dependency");
            for(int i=0;i<dependencies.getLength();i++) {
            	Element dependency = (Element) dependencies.item(i);
            	Element artifactId = (Element) dependency.getElementsByTagName("artifactId").item(0);
            	Element groupId = (Element) dependency.getElementsByTagName("groupId").item(0);
            }
            
            return;

            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

