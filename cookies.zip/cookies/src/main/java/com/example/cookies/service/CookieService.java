package com.example.cookies.service;

import org.springframework.stereotype.Service;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class CookieService {
	
	Cookie cookie;
	
	public String setCookie(HttpServletResponse response, String username) {
		cookie = new Cookie("username", username);
		cookie.setMaxAge(60 * 2); // Set cookie to expire in 1 day
        cookie.setPath("/"); // Make the cookie available for the entire application
        response.addCookie(cookie);
        return "Cookie set!";
    }

	public String getCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if ("username".equals(cookie.getName())) {
					return "Username cookie value: " + cookie.getValue();
				}
			}
		}
		return "No cookie found!";
	}
	
	public String destroyCookie(HttpServletResponse response) {
		cookie = new Cookie("username", null);
		cookie.setMaxAge(0);
		cookie.setPath("/");
		response.addCookie(cookie);
		
		return "cookie destroyed";
	}

}
