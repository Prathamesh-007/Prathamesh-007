package com.example.cookies.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.cookies.service.CookieService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/test")
public class TestController {
	
	@Autowired
	CookieService cookieService;
	
	@GetMapping("")
	public String home() {
		System.out.println("Home Page");
//		return cookieService.getCookie(request);
		return "home";
	}
	
	@GetMapping("/")
	public String show(HttpServletRequest request) {
		System.out.println(cookieService.getCookie(request));
		
		return "signin";
	}
	
	@RequestMapping("/signin")
	public String signin(HttpServletResponse response, @RequestParam String username, @RequestParam String password) {
//		System.out.println(object.getClass());
		System.out.println(username);
		cookieService.setCookie(response, username);
		return "signin";
	}
	
	@RequestMapping("/signout")
	public String singout(HttpServletResponse response) {
		cookieService.destroyCookie(response);
		return "home";
		
	}

}

