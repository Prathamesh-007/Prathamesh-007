package Rectangle;

public class Box extends Rectangle{
	int height;

	public Box(int length, int breadth, int height) {
		super(length, breadth);
		this.height = height;
	}
	
	public int volume() {
		return this.area()*this.height;
	}


	
	
}
