package FDPackage;

public class FixedDepositDemo {
	
	public static void main(String[] args) {
		FixedDeposit fd1 = new FixedDeposit();
		FixedDeposit fd2 = new FixedDeposit(12000, 10, 2);
		
		fd1.display();
		fd2.display();
		

	}
	
	

}
