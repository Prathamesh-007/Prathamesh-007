package FDPackage;

public class FixedDeposit {
	double principalAmount;
	double annualInterestRate;
	double period;

	// No argument Constructor
	public FixedDeposit() {
		principalAmount = 1000;
		annualInterestRate = 5;
		period = 3;
	}
	
	// Parameterized Constructor
	public FixedDeposit(double principalAmount, double annualInterestRate, double period) {
		this.principalAmount = principalAmount;
		this.annualInterestRate = annualInterestRate;
		this.period = period;
	}
	
	// Accessor for principalAmount
	public double getPrincipalAmount() {
		return principalAmount;
	}

	// Mutator for principalAmount
	public void setPrincipalAmount(double principalAmount) {
		this.principalAmount = principalAmount;
	}

	// Accessor for annualInterestRate
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	// Mutator for annualInterestRate
	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}

	// Accessor for period
	public double getPeriod() {
		return period;
	}

	// Mutator for period
	public void setPeriod(double period) {
		this.period = period;
	}

	// Function for Compound Interest
	public double compoundInterest() {
		double amount = principalAmount * Math.pow((1+annualInterestRate/100), period);
		return amount;
	}
	
	// Display method
	public void display() {
		System.out.println("Principal Amount: " + principalAmount);
		System.out.println("Annual Interest Rate:" + annualInterestRate);
		System.out.println("Period: " + period);
		System.out.println("Compound Interest: " + this.compoundInterest());
	}

}
