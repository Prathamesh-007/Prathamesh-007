package main;

import javax.security.auth.x500.X500Principal;

public class Grades {

	public static void main(String[] args) {
		int marks = 85;
		
		switch (marks/10) {
		case 10:
		case 9:
			System.out.println("A Grade");
			break;
			
		case 8:
			System.out.println("B Grade");
			break;
			
		case 7:
			System.out.println("C Grade");
			

		default:
			break;
		}

	}

}
