package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		double purchase = scanner.nextDouble();
		double discount = 0;
		double finalPrice = 0;
		
		if(purchase>5000) {
			discount = purchase * 10/100;
			finalPrice = purchase - discount;
		}
		
		else {
			finalPrice = purchase;
		}
		
		System.out.println("Original Price: " + purchase);
		System.out.println("Discount: " + discount);
		System.out.println("Final Price: " + finalPrice);
		
	}

}
